#Zulal Karin Machine Learning HW2
#implementing Neural Network

import numpy as np
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split

def sigmoid(z):
    return 1.0 / (1 + np.exp(-z))

def sigmoid_derivative(z):
    return z * (1.0 - z)

class NeuralNetwork:
    def __init__(self, inSize, sl2, clsSize, lrt):
        self.iSz = inSize  # input size, not counting bias
        self.oSz = clsSize  # output size, i.e. number of units in the output layer
        self.hSz = sl2  # number of units in the hidden layer

        # Weights are initialized here
        np.random.seed(42)
        self.weights1 = (np.random.rand(self.hSz, self.iSz + 1) - 0.5) / np.sqrt(self.iSz)
        self.weights2 = (np.random.rand(self.oSz, self.hSz + 1) - 0.5) / np.sqrt(self.hSz)

        self.output = np.zeros(clsSize)

        self.layer1 = np.zeros(self.hSz)
        self.eta = lrt

    def feedforward(self, x):
        x_bias = np.append(x, 1)  # Append bias to input
        self.layer1 = sigmoid(np.dot(self.weights1, x_bias))
        layer1_bias = np.append(self.layer1, 1)
        self.output = sigmoid(np.dot(self.weights2, layer1_bias))  # Append bias to hidden layer output

    def backprop(self, x, trg):
        delta_2 = trg - self.output
        delta_2 = delta_2 * sigmoid_derivative(self.output)

        # Calculate error for the hidden layer
        delta_1 = np.dot(self.weights2.T, delta_2)
        delta_1 = delta_1[:-1]  # Remove the bias term
        delta_1 = delta_1 * sigmoid_derivative(self.layer1)

        # Update weights
        delta_weight_1 = np.outer(delta_1, np.append(x, 1))
        delta_weight_2 = np.outer(delta_2, np.append(self.layer1, 1))

        return delta_weight_1, delta_weight_2 # Return the weight updates

    def fit(self, X, y, iterNo):
        m = X.shape[0]

        for i in range(iterNo):
            D1 = np.zeros(self.weights1.shape)
            D2 = np.zeros(self.weights2.shape)

            for j in range(m):
                self.feedforward(X[j])
                yt = np.zeros(self.oSz)
                yt[int(y[j])] = 1
                dW1, dW2 = self.backprop(X[j], yt)
                D1 += dW1
                D2 += dW2

            self.weights1 += self.eta * (D1 / m)
            self.weights2 += self.eta * (D2 / m)

    def predict(self, X):
        m = X.shape[0]
        y_proba = np.zeros((m, self.oSz))
        y = np.zeros(m)

        for i in range(m):
            self.feedforward(X[i])
            y_proba[i, :] = self.output
            y[i] = np.argmax(self.output)

        return y, y_proba

# Load digits dataset
digits = load_digits()
# print(digits.data.shape)
(1797, 64)
# print(digits.target_names)
X = digits.data
y = digits.target

# Split the data into train and test sets
X_train, Xtest, Y_train, Ytest = train_test_split(X, y, test_size=0.2, random_state=42)
Xtrain, Xvalid, Ytrain, Yvalid = train_test_split(X_train, Y_train, test_size=0.2, random_state=42)
# print(Xtrain.shape)
# print(Xvalid.shape)
# print(Xtest.shape)
# print(Ytest)

# Create an instance of NeuralNetwork
nn = NeuralNetwork(inSize=X.shape[1], sl2=64, clsSize=len(digits.target_names), lrt=0.1)

# Train the neural network
nn.fit(X_train, Y_train, iterNo=100)

# Predict labels for the test set
y_pred, y_proba = nn.predict(Xtest)

# Calculate accuracy
accuracy = (y_pred == Ytest).mean()
# print("Accuracy:", accuracy)

#Question2 - A

learning_rates = [0.01, 0.1, 0.5, 0.9]
best_learning_rate = None
best_accuracy = 0
for rate in learning_rates:
    nn = NeuralNetwork(inSize=X.shape[1], sl2=64, clsSize=len(digits.target_names), lrt=rate)
    nn.fit(X_train, Y_train, iterNo=100)
    y_pred_valid, _ = nn.predict(Xvalid)
    accuracy = (y_pred_valid == Yvalid).mean()
    print(f"Learning Rate: {rate}, Accuracy: {accuracy}")

    if accuracy > best_accuracy:
        best_accuracy = accuracy
        best_learning_rate = rate

print("Best Learning Rate:", best_learning_rate)

#Question2 - B

hidden_units = [16, 32, 64, 128]
best_hidden_units = None
best_accuracy_hidden_units = 0
print("")

for units in hidden_units:
    nn = NeuralNetwork(inSize=X.shape[1], sl2=units, clsSize=len(digits.target_names), lrt=best_learning_rate);
    nn.fit(X_train, Y_train, iterNo=100)
    y_pred_valid, _ = nn.predict(Xvalid)
    accuracy = (y_pred_valid == Yvalid).mean()
    print(f"Hidden Units: {units}, Accuracy: {accuracy}")

    # Update best number of hidden units if the current one performs better
    if accuracy > best_accuracy_hidden_units:
        best_accuracy_hidden_units = accuracy
        best_hidden_units = units

print("Best Number of Hidden Units:", best_hidden_units)


#Question2 - C

# Combine train and validation sets
X_combined = np.concatenate((X_train, Xvalid))
y_combined = np.concatenate((Y_train, Yvalid))

# Train the network on the combined train and validation sets using the best hyperparameters
nn_final = NeuralNetwork(inSize=X.shape[1], sl2=best_hidden_units, clsSize=len(digits.target_names), lrt=best_learning_rate)
nn_final.fit(X_combined, y_combined, iterNo=100)

# Predict labels for the test set
y_pred_test, _ = nn_final.predict(Xtest)

# Calculate accuracy on the test set
accuracy_test = (y_pred_test == Ytest).mean()
print("")
print("Test Set Accuracy:", accuracy_test)
# Calculating confusion matrix
confusion_matrix = np.zeros((len(digits.target_names), len(digits.target_names)), dtype=int)
for true_label, predicted_label in zip(Ytest, y_pred_test):
    true_label = int(true_label)
    predicted_label = int(predicted_label)
    confusion_matrix[true_label, predicted_label] += 1
print("Confusion Matrix:")
print(confusion_matrix)
